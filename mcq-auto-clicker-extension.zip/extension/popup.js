function setStatus(message) {
  document.getElementById("status").textContent = message;
}

/*
 * Supports:
 *
 * 1-B 2-A 3-C
 *
 * 1. B
 * 2. A
 *
 * 1. 1
 * 2. 1
 * 3. 2, 3
 * 4. 1, 4
 *
 * Also accepts:
 * 1: 1
 * 2: 2, 3
 */

function parseAnswers(text) {
  const answers = {};

  const lines = text
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);

  for (const line of lines) {
    /*
     * Format:
     * 1. 1
     * 3. 2, 3
     */
    let match = line.match(
      /^(\d+)\s*[.):]\s*([1-6](?:\s*,\s*[1-6])*)\s*$/
    );

    if (match) {
      const question = match[1];

      const values = match[2]
        .split(",")
        .map(value => value.trim())
        .filter(Boolean);

      if (answers[question]) {
        throw new Error(
          `Duplicate answer for Q${question}`
        );
      }

      answers[question] = values;
      continue;
    }

    /*
     * Format:
     * 1-B
     * 2-A
     * 3-C
     */
    match = line.match(
      /^(\d+)\s*[-:=]\s*([A-Fa-f])$/
    );

    if (match) {
      const question = match[1];
      const letter = match[2].toUpperCase();

      if (answers[question]) {
        throw new Error(
          `Duplicate answer for Q${question}`
        );
      }

      answers[question] = [letter];
      continue;
    }

    /*
     * Format:
     * 1. B
     * 2: C
     */
    match = line.match(
      /^(\d+)\s*[.):]\s*([A-Fa-f])$/
    );

    if (match) {
      const question = match[1];
      const letter = match[2].toUpperCase();

      if (answers[question]) {
        throw new Error(
          `Duplicate answer for Q${question}`
        );
      }

      answers[question] = [letter];
      continue;
    }

    /*
     * Ignore blank/separator lines.
     */
  }

  /*
   * Also support everything on one line:
   *
   * 1. 1 2. 1 3. 2, 3
   */
  if (Object.keys(answers).length === 0) {
    const pattern =
      /(\d+)\s*[.):]\s*([1-6](?:\s*,\s*[1-6])*)/g;

    let match;

    while ((match = pattern.exec(text)) !== null) {
      const question = match[1];

      const values = match[2]
        .split(",")
        .map(value => value.trim());

      if (answers[question]) {
        throw new Error(
          `Duplicate answer for Q${question}`
        );
      }

      answers[question] = values;
    }
  }

  if (Object.keys(answers).length === 0) {
    throw new Error(
      "No answers found. Example:\n1. 1\n2. 1\n3. 2, 3"
    );
  }

  return answers;
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });

  if (!tabs.length) {
    throw new Error("No active tab found.");
  }

  return tabs[0];
}

async function injectContentScript(tabId) {
  await chrome.scripting.executeScript({
    target: {
      tabId
    },
    files: ["content.js"]
  });
}

async function sendToActiveTab(message) {
  const tab = await getActiveTab();

  if (!tab.id) {
    throw new Error("Active tab has no valid ID.");
  }

  try {
    return await chrome.tabs.sendMessage(
      tab.id,
      message
    );
  } catch (_) {
    await injectContentScript(tab.id);

    return await chrome.tabs.sendMessage(
      tab.id,
      message
    );
  }
}

document.getElementById("scan").addEventListener(
  "click",
  async () => {
    try {
      setStatus("Scanning current tab...");

      const result =
        await sendToActiveTab({
          type: "SCAN"
        });

      if (!result || !result.success) {
        throw new Error(
          result?.error ||
          "Scan failed."
        );
      }

      const lines = [];

      lines.push(
        `Detected: ${result.count} questions`
      );

      lines.push("");

      for (const question of result.questions) {
        lines.push(
          `Q${question.number}: ${question.text}`
        );

        for (const option of question.options) {
          lines.push(
            `  ${option.value} / ${option.number} -> ${option.text}`
          );
        }

        lines.push("");
      }

      setStatus(lines.join("\n"));

    } catch (error) {
      setStatus(
        "ERROR: " + error.message
      );
    }
  }
);

document.getElementById("select").addEventListener(
  "click",
  async () => {
    try {
      const text =
        document.getElementById(
          "answers"
        ).value;

      const answers =
        parseAnswers(text);

      const totalAnswers =
        Object.values(answers)
          .reduce(
            (total, values) =>
              total + values.length,
            0
          );

      setStatus(
        `Parsed ${Object.keys(answers).length} questions / ${totalAnswers} selections.\n\nSelecting...`
      );

      const result =
        await sendToActiveTab({
          type: "SELECT_AND_VERIFY",
          answers
        });

      if (!result) {
        throw new Error(
          "No response from page."
        );
      }

      const lines = [];

      lines.push(
        result.success
          ? "SUCCESS"
          : "COMPLETED WITH ISSUES"
      );

      lines.push("");

      lines.push(
        `Detected : ${result.detected}`
      );

      lines.push(
        `Provided : ${result.provided}`
      );

      lines.push(
        `Selected : ${result.selected}`
      );

      lines.push(
        `Verified : ${result.verified}`
      );

      lines.push(
        `Failed   : ${result.failed}`
      );

      lines.push(
        `Missing  : ${result.missing || 0}`
      );

      lines.push("");

      for (const item of result.results) {
        if (
          item.status === "VERIFIED"
        ) {
          lines.push(
            `Q${item.question}: ${item.expected.join(", ")} -> VERIFIED`
          );
        } else {
          lines.push(
            `Q${item.question}: ${item.status}`
          );
        }
      }

      setStatus(
        lines.join("\n")
      );

    } catch (error) {
      setStatus(
        "ERROR: " + error.message
      );
    }
  }
);
