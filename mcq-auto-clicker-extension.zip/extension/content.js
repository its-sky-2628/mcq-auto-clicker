(() => {
  /*
   * MCQ Auto Clicker
   *
   * For local/authorized practice pages.
   * Selects and verifies options.
   * Does NOT submit the page/form.
   */

  function cleanText(text) {
    return (text || "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function letterToIndex(letter) {
    const value = String(letter || "")
      .trim()
      .toUpperCase();

    if (!/^[A-F]$/.test(value)) {
      return -1;
    }

    return value.charCodeAt(0) -
      "A".charCodeAt(0);
  }

  function numberToIndex(number) {
    const value = Number(number);

    if (
      !Number.isInteger(value) ||
      value < 1
    ) {
      return -1;
    }

    return value - 1;
  }

  function getExplicitValue(element) {
    if (!element) {
      return "";
    }

    const attrs = [
      "value",
      "data-option",
      "data-answer",
      "data-value",
      "aria-label"
    ];

    for (const attr of attrs) {
      const value =
        element.getAttribute(attr);

      if (value) {
        return cleanText(value);
      }
    }

    return "";
  }

  function getOptionText(element) {
    if (!element) {
      return "";
    }

    const label =
      element.closest("label");

    if (label) {
      return cleanText(label.innerText);
    }

    const id =
      element.getAttribute("id");

    if (id) {
      try {
        const labelByFor =
          document.querySelector(
            `label[for="${CSS.escape(id)}"]`
          );

        if (labelByFor) {
          return cleanText(
            labelByFor.innerText
          );
        }
      } catch (_) {}
    }

    const parent =
      element.parentElement;

    if (parent) {
      return cleanText(
        parent.innerText
      );
    }

    return "";
  }

  function findQuestionContainer(element) {
    const selectors = [
      "fieldset",
      "[data-question]",
      "[data-question-id]",
      "[data-testid*='question']",
      ".question",
      ".mcq",
      ".quiz-question",
      ".question-card",
      ".question-container",
      ".quiz-item",
      ".card"
    ];

    for (const selector of selectors) {
      try {
        const parent =
          element.closest(selector);

        if (parent) {
          return parent;
        }
      } catch (_) {}
    }

    let current =
      element.parentElement;

    for (
      let depth = 0;
      current && depth < 8;
      depth++
    ) {
      const controls =
        current.querySelectorAll(
          'input[type="radio"], input[type="checkbox"], [role="radio"], [role="checkbox"]'
        );

      if (
        controls.length >= 2 &&
        controls.length <= 10
      ) {
        return current;
      }

      current =
        current.parentElement;
    }

    return element.parentElement;
  }

  function getQuestionText(container) {
    if (!container) {
      return "";
    }

    const lines =
      (container.innerText || "")
        .split("\n")
        .map(cleanText)
        .filter(Boolean);

    if (!lines.length) {
      return "";
    }

    for (const line of lines) {
      if (/^[A-F][.):\-]\s*/i.test(line)) {
        continue;
      }

      if (/^\d+\s*[.):\-]\s*/.test(line)) {
        continue;
      }

      if (/^[A-F]$/i.test(line)) {
        continue;
      }

      return line;
    }

    return lines[0];
  }

  function getGroups() {
    const groups =
      new Map();

    /*
     * Standard radio + checkbox inputs.
     */
    const inputs =
      Array.from(
        document.querySelectorAll(
          'input[type="radio"], input[type="checkbox"]'
        )
      );

    for (const input of inputs) {
      let name =
        input.getAttribute("name");

      if (!name) {
        name =
          input.getAttribute(
            "data-question"
          );
      }

      if (!name) {
        name =
          input.getAttribute(
            "data-question-id"
          );
      }

      /*
       * Some checkbox layouts don't use name.
       * Group them by their nearest question container.
       */
      if (!name) {
        const container =
          findQuestionContainer(input);

        if (container) {
          name =
            container.getAttribute(
              "data-question"
            ) ||
            container.getAttribute(
              "data-question-id"
            ) ||
            container.id ||
            `container-${groups.size + 1}`;
        }
      }

      if (!name) {
        continue;
      }

      if (!groups.has(name)) {
        groups.set(name, []);
      }

      groups
        .get(name)
        .push(input);
    }

    /*
     * Custom ARIA controls.
     */
    const custom =
      Array.from(
        document.querySelectorAll(
          '[role="radio"], [role="checkbox"]'
        )
      );

    for (const element of custom) {
      const container =
        element.closest(
          '[role="radiogroup"], [data-question], [data-question-id], fieldset, .question, .mcq, .question-card'
        );

      let name = null;

      if (container) {
        name =
          container.getAttribute(
            "data-question"
          ) ||
          container.getAttribute(
            "data-question-id"
          ) ||
          container.id;
      }

      if (!name) {
        name =
          `custom-${groups.size + 1}`;
      }

      if (!groups.has(name)) {
        groups.set(name, []);
      }

      if (
        !groups.get(name)
          .includes(element)
      ) {
        groups
          .get(name)
          .push(element);
      }
    }

    return groups;
  }

  function makeQuestion(
    group,
    number,
    identifier
  ) {
    const options = [];

    for (
      let index = 0;
      index < group.length;
      index++
    ) {
      const element =
        group[index];

      const explicit =
        getExplicitValue(element);

      const text =
        getOptionText(element);

      let value = "";

      /*
       * Explicit A/B/C/D value.
       */
      if (/^[A-F]$/i.test(explicit)) {
        value =
          explicit.toUpperCase();
      }

      /*
       * Explicit numeric value.
       */
      if (!value && /^\d+$/.test(explicit)) {
        const n =
          Number(explicit);

        if (
          n >= 1 &&
          n <= 6
        ) {
          value =
            String.fromCharCode(
              "A".charCodeAt(0) +
              n -
              1
            );
        }
      }

      /*
       * Visible A/B/C/D.
       */
      if (!value) {
        const letterMatch =
          text.match(
            /^\s*([A-F])\s*[.):\-]/i
          );

        if (letterMatch) {
          value =
            letterMatch[1]
              .toUpperCase();
        }
      }

      /*
       * Visible 1/2/3/4.
       */
      if (!value) {
        const numberMatch =
          text.match(
            /^\s*(\d+)\s*[.):\-]/
          );

        if (numberMatch) {
          const n =
            Number(
              numberMatch[1]
            );

          if (
            n >= 1 &&
            n <= 6
          ) {
            value =
              String.fromCharCode(
                "A".charCodeAt(0) +
                n -
                1
              );
          }
        }
      }

      /*
       * FINAL FALLBACK:
       *
       * position 0 = A
       * position 1 = B
       * position 2 = C
       * position 3 = D
       */
      if (!value) {
        value =
          String.fromCharCode(
            "A".charCodeAt(0) +
            index
          );
      }

      options.push({
        index,
        value,
        number: index + 1,
        text,
        element
      });
    }

    const container =
      group.length
        ? findQuestionContainer(
            group[0]
          )
        : null;

    /*
     * Detect control type.
     */
    let multiple = false;

    for (const option of options) {
      const element =
        option.element;

      const type =
        (
          element.getAttribute(
            "type"
          ) || ""
        ).toLowerCase();

      const role =
        (
          element.getAttribute(
            "role"
          ) || ""
        ).toLowerCase();

      if (
        type === "checkbox" ||
        role === "checkbox"
      ) {
        multiple = true;
      }
    }

    return {
      number,
      identifier,
      text:
        getQuestionText(
          container
        ),
      multiple,
      options
    };
  }

  function scanQuestions() {
    const groups =
      getGroups();

    const questions = [];

    let number = 1;

    for (
      const [
        identifier,
        group
      ] of groups
    ) {
      /*
       * Ignore obvious non-question
       * controls.
       */
      if (
        group.length < 2 ||
        group.length > 10
      ) {
        continue;
      }

      questions.push(
        makeQuestion(
          group,
          number,
          identifier
        )
      );

      number++;
    }

    return questions;
  }

  function findOption(
    question,
    answer
  ) {
    const value =
      String(answer || "")
        .trim()
        .toUpperCase();

    /*
     * A/B/C/D.
     */
    if (/^[A-F]$/.test(value)) {
      const index =
        letterToIndex(value);

      if (
        index >= 0 &&
        index <
          question.options.length
      ) {
        return question
          .options[index];
      }
    }

    /*
     * 1/2/3/4.
     */
    if (/^\d+$/.test(value)) {
      const index =
        numberToIndex(value);

      if (
        index >= 0 &&
        index <
          question.options.length
      ) {
        return question
          .options[index];
      }
    }

    return null;
  }

  function clickOption(option) {
    if (!option || !option.element) {
      return false;
    }

    const element =
      option.element;

    try {
      element.scrollIntoView({
        behavior: "instant",
        block: "center"
      });
    } catch (_) {}

    /*
     * Standard checkbox/radio.
     */
    if (
      element.matches &&
      element.matches(
        'input[type="checkbox"], input[type="radio"]'
      )
    ) {
      try {
        element.click();

        return true;
      } catch (_) {}
    }

    /*
     * Custom control.
     */
    try {
      element.click();

      return true;
    } catch (_) {}

    /*
     * Label / card fallback.
     */
    const clickable =
      element.closest(
        "label, button, [role='radio'], [role='checkbox'], [role='option'], .option, .choice"
      );

    if (
      clickable &&
      clickable !== element
    ) {
      try {
        clickable.click();

        return true;
      } catch (_) {}
    }

    return false;
  }

  function isSelected(
    option
  ) {
    if (!option) {
      return false;
    }

    const element =
      option.element;

    /*
     * Native controls.
     */
    if (
      element.matches &&
      element.matches(
        'input[type="radio"], input[type="checkbox"]'
      )
    ) {
      return element.checked;
    }

    /*
     * ARIA.
     */
    const ariaChecked =
      element.getAttribute(
        "aria-checked"
      );

    if (
      ariaChecked === "true"
    ) {
      return true;
    }

    /*
     * Common custom-state classes.
     */
    const parent =
      element.closest(
        ".selected, .checked, .active, .is-selected, .is-checked"
      );

    if (parent) {
      return true;
    }

    /*
     * aria-selected.
     */
    if (
      element.getAttribute(
        "aria-selected"
      ) === "true"
    ) {
      return true;
    }

    return false;
  }

  function normalizeExpected(
    question,
    values
  ) {
    const normalized = [];

    for (const value of values) {
      const option =
        findOption(
          question,
          value
        );

      if (
        option &&
        !normalized.includes(
          option.value
        )
      ) {
        normalized.push(
          option.value
        );
      }
    }

    return normalized;
  }

  async function selectQuestion(
    question,
    answers
  ) {
    const expected =
      normalizeExpected(
        question,
        answers
      );

    if (!expected.length) {
      return {
        success: false,
        reason:
          "No valid options found"
      };
    }

    /*
     * Multi-select:
     * click every requested option.
     */
    if (question.multiple) {
      for (const value of expected) {
        const option =
          question.options.find(
            item =>
              item.value === value
          );

        if (!option) {
          return {
            success: false,
            reason:
              `Option ${value} not found`
          };
        }

        if (!isSelected(option)) {
          const clicked =
            clickOption(option);

          if (!clicked) {
            return {
              success: false,
              reason:
                `Could not click ${value}`
            };
          }

          await new Promise(
            resolve =>
              setTimeout(
                resolve,
                80
              )
          );
        }
      }

      return {
        success: true,
        expected
      };
    }

    /*
     * Single-select:
     * click the first expected option.
     */
    const option =
      question.options.find(
        item =>
          item.value ===
          expected[0]
      );

    if (!option) {
      return {
        success: false,
        reason:
          `Option ${expected[0]} not found`
      };
    }

    if (!isSelected(option)) {
      const clicked =
        clickOption(option);

      if (!clicked) {
        return {
          success: false,
          reason:
            `Could not click ${expected[0]}`
        };
      }
    }

    await new Promise(
      resolve =>
        setTimeout(
          resolve,
          100
        )
    );

    return {
      success: true,
      expected
    };
  }

  function verifyQuestion(
    question,
    answers
  ) {
    const expected =
      normalizeExpected(
        question,
        answers
      );

    if (!expected.length) {
      return {
        success: false,
        actual: [],
        reason:
          "No valid expected options"
      };
    }

    const actual =
      question.options
        .filter(
          option =>
            isSelected(option)
        )
        .map(
          option =>
            option.value
        );

    /*
     * Single select.
     */
    if (!question.multiple) {
      const success =
        actual.length === 1 &&
        actual[0] ===
          expected[0];

      return {
        success,
        actual,
        expected
      };
    }

    /*
     * Multi-select:
     * Compare sets exactly.
     */
    const expectedSet =
      new Set(expected);

    const actualSet =
      new Set(actual);

    const success =
      expectedSet.size ===
        actualSet.size &&
      [...expectedSet].every(
        value =>
          actualSet.has(value)
      );

    return {
      success,
      actual,
      expected
    };
  }

  async function selectAndVerify(
    answers
  ) {
    const questions =
      scanQuestions();

    const results = [];

    let selected = 0;
    let verified = 0;
    let failed = 0;
    let missing = 0;

    for (const question of questions) {
      const answer =
        answers[
          String(question.number)
        ];

      if (
        !answer ||
        !answer.length
      ) {
        missing++;

        results.push({
          question:
            question.number,

          status:
            "MISSING"
        });

        continue;
      }

      const selection =
        await selectQuestion(
          question,
          answer
        );

      if (!selection.success) {
        failed++;

        results.push({
          question:
            question.number,

          expected:
            answer,

          status:
            "SELECTION_FAILED",

          reason:
            selection.reason
        });

        continue;
      }

      selected++;

      const verification =
        verifyQuestion(
          question,
          answer
        );

      if (verification.success) {
        verified++;

        results.push({
          question:
            question.number,

          expected:
            verification.expected,

          actual:
            verification.actual,

          status:
            "VERIFIED"
        });
      } else {
        failed++;

        results.push({
          question:
            question.number,

          expected:
            verification.expected,

          actual:
            verification.actual,

          status:
            "VERIFICATION_FAILED",

          reason:
            verification.reason
        });
      }
    }

    return {
      success:
        failed === 0 &&
        missing === 0,

      detected:
        questions.length,

      provided:
        Object.keys(answers).length,

      selected,
      verified,
      failed,
      missing,

      results
    };
  }

  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      (async () => {
        try {
          if (
            message.type ===
            "SCAN"
          ) {
            const questions =
              scanQuestions();

            sendResponse({
              success: true,
              count:
                questions.length,

              questions:
                questions.map(
                  question => ({
                    number:
                      question.number,

                    identifier:
                      question.identifier,

                    text:
                      question.text,

                    multiple:
                      question.multiple,

                    options:
                      question.options.map(
                        option => ({
                          value:
                            option.value,

                          number:
                            option.number,

                          index:
                            option.index,

                          text:
                            option.text
                        })
                      )
                  })
                )
            });

            return;
          }

          if (
            message.type ===
            "SELECT_AND_VERIFY"
          ) {
            const result =
              await selectAndVerify(
                message.answers || {}
              );

            sendResponse(result);
            return;
          }

          sendResponse({
            success: false,
            error:
              "Unknown command"
          });

        } catch (error) {
          sendResponse({
            success: false,
            error:
              error.message
          });
        }
      })();

      return true;
    }
  );
})();
